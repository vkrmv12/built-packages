TERMUX_SUBPKG_DESCRIPTION="Erlang HTML documentation"
TERMUX_SUBPKG_PLATFORM_INDEPENDENT=true
TERMUX_SUBPKG_INCLUDE="
lib/erlang/doc
lib/erlang/*/doc
lib/erlang/*/*/doc
"
