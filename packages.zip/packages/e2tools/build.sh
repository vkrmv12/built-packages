TERMUX_PKG_HOMEPAGE=https://github.com/e2tools/e2tools
TERMUX_PKG_DESCRIPTION="mtools analogue for ext2/3 filesystems"
TERMUX_PKG_LICENSE="GPL-2.0"
TERMUX_PKG_MAINTAINER="@termux"
TERMUX_PKG_VERSION="0.1.2"
TERMUX_PKG_REVISION=1
TERMUX_PKG_SRCURL=https://github.com/e2tools/e2tools/releases/download/v$TERMUX_PKG_VERSION/e2tools-$TERMUX_PKG_VERSION.tar.gz
TERMUX_PKG_SHA256=b19593bbfc85e9c14c0d2bc8525887901c8fe02588c76df60ab843bf0573c4a2
TERMUX_PKG_DEPENDS="e2fsprogs"
TERMUX_PKG_AUTO_UPDATE=true

# Force linking against the static com_err library (shared one lacks _et_list).
_TERMUX_E2TOOLS_LIBS="-lext2fs -l:libcom_err.a"

termux_step_make() {
	[ "$TERMUX_PKG_METAPACKAGE" = "true" ] && return

	local quiet_build=""
	if [ "$TERMUX_QUIET_BUILD" = true ]; then
		quiet_build="-s"
	fi

	make -j "$TERMUX_PKG_MAKE_PROCESSES" $quiet_build \
		LIBS="$_TERMUX_E2TOOLS_LIBS"
}

termux_step_make_install() {
	[ "$TERMUX_PKG_METAPACKAGE" = "true" ] && return

	local install_target=${TERMUX_PKG_MAKE_INSTALL_TARGET:-install}
	make -j 1 LIBS="$_TERMUX_E2TOOLS_LIBS" "$install_target"
}
