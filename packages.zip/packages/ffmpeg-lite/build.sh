TERMUX_PKG_HOMEPAGE=https://ffmpeg.org
TERMUX_PKG_DESCRIPTION="Lite ffmpeg build for local MP4/WebM/HLS merging (no network, minimal deps)"
TERMUX_PKG_LICENSE="GPL-3.0"
TERMUX_PKG_MAINTAINER="@termux"

TERMUX_PKG_NAME=ffmpeg-lite
TERMUX_PKG_VERSION="7.1.2"
TERMUX_PKG_SRCURL=https://www.ffmpeg.org/releases/ffmpeg-${TERMUX_PKG_VERSION}.tar.xz
TERMUX_PKG_SHA256=089bc60fb59d6aecc5d994ff530fd0dcb3ee39aa55867849a2bbc4e555f9c304

# Only what we really need for a basic, shared ffmpeg that works on local files.
TERMUX_PKG_DEPENDS="libandroid-glob"
TERMUX_PKG_CONFLICTS="ffmpeg, libav"
TERMUX_PKG_BREAKS=""
TERMUX_PKG_REPLACES=""

termux_step_pre_configure() {
	# SOVERSION guard (same as main ffmpeg package).
	_FFMPEG_SOVER_avutil=59
	_FFMPEG_SOVER_avcodec=61
	_FFMPEG_SOVER_avformat=61

	local f
	for f in util codec format; do
		local v=$(sh ffbuild/libversion.sh av${f} \
			libav${f}/version.h libav${f}/version_major.h \
			| sed -En 's/^libav'"${f}"'_VERSION_MAJOR=([0-9]+)$/\1/p')
		if [ ! "${v}" ] || [ "$(eval echo \$_FFMPEG_SOVER_av${f})" != "${v}" ]; then
			termux_error_exit "SOVERSION guard check failed for libav${f}.so. expected ${v}"
		fi
	done

	# 32-bit ARM workaround from original package:
	if [ "$TERMUX_ARCH" = "arm" ]; then
		CFLAGS+=" -Wno-error=incompatible-pointer-types"
	fi
}

termux_step_configure() {
	cd "$TERMUX_PKG_BUILDDIR"

	local _EXTRA_CONFIGURE_FLAGS=""
	if [ "$TERMUX_ARCH" = "arm" ]; then
		_ARCH="armeabi-v7a"
		_EXTRA_CONFIGURE_FLAGS="--enable-neon"
	elif [ "$TERMUX_ARCH" = "i686" ]; then
		_ARCH="x86"
		# Prevent text relocations on i686
		_EXTRA_CONFIGURE_FLAGS="--disable-asm"
	elif [ "$TERMUX_ARCH" = "x86_64" ]; then
		_ARCH="x86_64"
	elif [ "$TERMUX_ARCH" = "aarch64" ]; then
		_ARCH="$TERMUX_ARCH"
		_EXTRA_CONFIGURE_FLAGS="--enable-neon"
	else
		termux_error_exit "Unsupported arch: $TERMUX_ARCH"
	fi

	"$TERMUX_PKG_SRCDIR"/configure \
		--arch="${_ARCH}" \
		--as="$AS" \
		--cc="$CC" \
		--cxx="$CXX" \
		--nm="$NM" \
		--ar="$AR" \
		--ranlib="llvm-ranlib" \
		--pkg-config="$PKG_CONFIG" \
		--strip="$STRIP" \
		--cross-prefix="${TERMUX_HOST_PLATFORM}-" \
		--enable-cross-compile \
		--target-os=android \
		--prefix="$TERMUX_PREFIX" \
		--enable-shared \
		--disable-static \
		--disable-symver \
		--disable-debug \
		--disable-doc \
		--disable-network \
		--disable-autodetect \
		--disable-everything \
		--enable-ffmpeg \
		--disable-ffplay \
		--disable-ffprobe \
                --enable-protocol=file \
                --enable-protocol=pipe \
                --enable-demuxer=mpegts \
                --enable-demuxer=mov,mp4,m4a \
                --enable-demuxer=matroska,webm \
                --enable-demuxer=concat \
                --enable-muxer=mp4 \
                --enable-muxer=matroska,webm \
		--enable-decoder=h264,hevc \
		--enable-decoder=vp8,vp9 \
		--enable-decoder=aac,mp3,mp2,opus,vorbis,pcm_s16le \
		--enable-parser=h264,hevc,vp8,vp9,aac,opus,vorbis \
		--enable-bsf=aac_adtstoasc,h264_metadata,hevc_metadata \
		--disable-zlib \
		--disable-bzlib \
		--disable-lzma \
		--disable-iconv \
		--disable-libxml2 \
		--disable-libxcb \
		--disable-xlib \
		--disable-sdl2 \
		--disable-gnutls \
		--disable-libaom \
		--disable-libass \
		--disable-libbluray \
		--disable-libdav1d \
		--disable-libfontconfig \
		--disable-libfreetype \
		--disable-libfribidi \
		--disable-libglslang \
		--disable-libgme \
		--disable-libharfbuzz \
		--disable-libmp3lame \
		--disable-libopencore-amrnb \
		--disable-libopencore-amrwb \
		--disable-libopenmpt \
		--disable-libopus \
		--disable-libplacebo \
		--disable-librav1e \
		--disable-librubberband \
		--disable-libsoxr \
		--disable-libsrt \
		--disable-libssh \
		--disable-libsvtav1 \
		--disable-libtheora \
		--disable-libv4l2 \
		--disable-libvidstab \
		--disable-libvmaf \
		--disable-libvo-amrwbenc \
		--disable-libvorbis \
		--disable-libvpx \
		--disable-libwebp \
		--disable-libx264 \
		--disable-libx265 \
		--disable-libxvid \
		--disable-libzimg \
		--disable-libzmq \
		--disable-opencl \
		--disable-vulkan \
		--disable-mediacodec \
		--disable-lcms2 \
		--disable-filters \
		--disable-avdevice \
		--disable-devices \
		--disable-postproc \
		--enable-gpl \
		--enable-version3 \
		--disable-libfdk-aac \
		--extra-libs="-landroid-glob" \
		$_EXTRA_CONFIGURE_FLAGS
}

termux_step_post_massage() {
	cd "${TERMUX_PKG_MASSAGEDIR}/${TERMUX_PREFIX}/lib" || exit 1

	local f
	for f in util codec format; do
		local s
		s=$(eval echo \$_FFMPEG_SOVER_av${f})
		if [ ! "${s}" ]; then
			termux_error_exit "Empty SOVERSION for libav${f}."
		fi
		if [ ! -e "./libav${f}.so.${s}" ]; then
			ln -sf "libav${f}.so" "libav${f}.so.${s}"
		fi
	done
}

termux_step_create_debscripts() {
	sed -e "s|@TERMUX_PREFIX@|$TERMUX_PREFIX|g" \
		"$TERMUX_PKG_BUILDER_DIR/postinst.sh.in" > ./postinst
	chmod +x ./postinst
}
