TERMUX_SUBPKG_INCLUDE="lib/jvm/java-17-openjdk/lib/security/"
TERMUX_SUBPKG_DESCRIPTION="Common CA certificates (java keystore format)"
TERMUX_SUBPKG_PLATFORM_INDEPENDENT=true
