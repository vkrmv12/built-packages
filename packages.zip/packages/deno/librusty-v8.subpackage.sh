TERMUX_SUBPKG_DESCRIPTION="High quality Rust bindings to V8's C++ API"
TERMUX_SUBPKG_DEPEND_ON_PARENT=false
TERMUX_SUBPKG_INCLUDE="
include/librusty_v8/src_binding.rs
lib/librusty_v8.a
share/doc/librusty-v8/LICENSE
share/doc/librusty-v8/LICENSE.v8
"
